cd..
cd..
cd PITec\Programa
regsvr32 MSCOMM32.OCX